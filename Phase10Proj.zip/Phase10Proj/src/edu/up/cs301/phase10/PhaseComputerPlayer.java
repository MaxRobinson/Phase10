package edu.up.cs301.phase10;

import edu.up.cs301.game.GameComputerPlayer;
import edu.up.cs301.game.infoMsg.GameInfo;

public class PhaseComputerPlayer extends GameComputerPlayer {
	
	public PhaseComputerPlayer(String name){
		super(name);
	}

	@Override
	protected void receiveInfo(GameInfo info) {
		// TODO Auto-generated method stub
		
	}
	
}
