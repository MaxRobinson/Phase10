package edu.up.cs301.phase10;

import edu.up.cs301.game.Game;

public interface PhaseGame extends Game{

}
