package edu.up.cs301.phase10;

import edu.up.cs301.game.GamePlayer;

public interface PhasePlayer extends GamePlayer{

}
