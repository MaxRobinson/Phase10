/** Automatically generated file. DO NOT MODIFY */
package edu.up.cs301.game;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}