package edu.up.cs301.slapjack;

import edu.up.cs301.game.Game;

/**
 * An interface that implements a Slapjack game
 * 
 * @author Steven R. Vegdahl
 * @version 25 July 2002
 */
public interface SJGame extends Game
{
}
